# Choose a background: "none", "beach", "space", "forest", "city", or "classroom".
# To use your own PNG/GIF, put it in backgrounds/ and write its filename.
background = "forest"

# New simple shape library: triangle(), star(), rectangle(), venetian_blind(), etc.
from turtle_shapes import *
# OPTIONAL EASTER EGG GALLERY — remove # from both marked lines to enable.
# from easter_egg_gallery import easter_egg_sequence

"""STUDENT IMAGES: create pictures independently of sounds."""
from teacher_sequence import Pattern, triangle_shape, square_shape, pentagon_shape, hexagon_shape, star_shape, rectangle_shape

colors = ["red", "pink"]

letter_A = [
    ("speed", 20),  # Medium drawing speed
    ("color", "black"),
    ("width", 25),
    ("up", -4, 0),
    ("heading", 72),
    ("down",),
    ("forward", 3),
    ("heading", 288),
    ("forward", 3),
    ("up", -3, 1),
    ("heading", 0),
    ("down",),
    ("forward", 1),
]


letter_H = [
    ("speed", 20),  # Medium drawing speed
    ("color", "black"),
    ("width", 20),
    ("up", 3, 2),
    ("heading", 270),
    ("down",),
    ("forward", 4),
    ("up", 4, 2),
    ("heading", 270),
    ("down",),
    ("forward", 4),
    ("up", 3, 0),
    ("heading", 0),
    ("down",),
    ("forward", 1),
]


my_s = letter_s(x=0, y=2, radius=1,
color="black", speed=10, width = 60)
a =2
my_growth = growing_shapes(
    
    triangle, count=15,
    x=-5, y=-0,
    start_size=1, step=0.5,
    color="pink", width = 5
)

# Built-in rectangle example (4 squares wide, 2 squares high).
# Uncomment the entry in image_sequence below to display it.
rectangle = [
    ("color", "white"),
    ("fillcolor", "black"),
    ("begin_fill",),
] + (
    Pattern("Rectangle")
    .at(-5, -5)
    .shape(rectangle_shape(10, 10))
    .draw()
) + [
    ("end_fill",),
]

my_blinds = venetian_blind(
x=-4, y=-3, width=8,
slats=7, slat_height=0.55,
gap=0.3, color="white",
fill="white", speed=99
)


spinning_squares = []

for angle in range(0, 360, 30):
    spinning_squares += [
        ("up", 0, 0),
        ("heading", angle),
        ("down",),
        ("color","pink"),
        ("fillcolor","yellow"),
        ("begin_fill",),
        ("repeat", 4),
        ("forward", 2),
        ("turn", 90),
        ("end_repeat",),
        ("end_fill",),
    ]



# Students choose the order of images here.
my_spiral = spiral(x=0, y=0,
 turn=90, steps=12,
 growth=0.6, color="purple",
 speed=99, width = 20)


image_sequence = [
    ("blinds", my_blinds),
    ("Letter A", letter_A),
    ("S", my_s),  
    ("Letter H", letter_H),
    ("rect", rectangle),
    ("spiral",my_spiral),
    ("grow it", my_growth),
    ("spin",spinning_squares)
    
]
# EASY SHAPE LIBRARY EXAMPLES — uncomment one or more below in image_sequence.
# beach_sun = circle(x=3, y=3, radius=0.7, color="orange", fill="yellow")

# one_triangle = triangle(x=-2, y=-2, size=2, angle=45, color="green")
# blinds = venetian_blind(x=-4, y=-3, width=8, slats=7, slat_height=0.5)
# image_sequence.append(("Venetian blinds", blinds))

# OPTIONAL EASTER EGG GALLERY — uncomment this line AND the import above.
# image_sequence.extend(easter_egg_sequence)


# REPEAT A SHAPE (OPTIONAL)
# Remove the # from the next lines to make five rectangles in a row.
# my_rectangles = repeat_shape(
#     rectangle, count=5, x=-8, y=0, spacing=4,
#     width=3, height=2, color="blue"
# )
# image_sequence.append(("5 Rectangles", my_rectangles))

# REPEAT YOUR OWN DRAWING (OPTIONAL)
# Works with any drawing list that uses ("up", x, y) to position itself.
# my_repeated_lines = repeat_shape(my_blinds, count=3, spacing=3)
# image_sequence.append(("Repeated Drawing", my_repeated_lines))
