# Choose a background: "none", "beach", "space", "forest", "city", or "classroom".
# To use your own PNG/GIF, put it in backgrounds/ and write its filename.
background = "city"

# New simple shape library: triangle(), star(), rectangle(), venetian_blind(), etc.
from turtle_shapes import *
# OPTIONAL EASTER EGG GALLERY — remove # from both marked lines to enable.
from easter_egg_gallery import easter_egg_sequence

"""STUDENT IMAGES: create pictures independently of sounds."""
from teacher_sequence import Pattern, triangle_shape, square_shape, pentagon_shape, hexagon_shape, star_shape, rectangle_shape

colors = ["red", "pink"]
my_line = [
    
 ("up", -3, 0),
 ("heading", 45),
 ("color", "blue"),
 ("width", 4),
 ("down",),
 ("forward", 6),
 ("heading", -45),
 ("forward", 6),
  ("heading", 180),
 ("forward", 5),
 
]

my_square = square(x=-1, y=-1, size=2,
                   angle=0, color="green",
                   fill="lightgreen")

image_sequence = [
    ("Square", my_square),
    ("Blue Line", my_line),
]



  
    

# EASY SHAPE LIBRARY EXAMPLES — uncomment one or more below in image_sequence.
# beach_sun = circle(x=3, y=3, radius=0.7, color="orange", fill="yellow")

# one_triangle = triangle(x=-2, y=-2, size=2, angle=45, color="green")
# blinds = venetian_blind(x=-4, y=-3, width=8, slats=7, slat_height=0.5)
# image_sequence.append(("Venetian blinds", blinds))

# OPTIONAL EASTER EGG GALLERY — uncomment this line AND the import above.
# image_sequence.extend(easter_egg_sequence)
