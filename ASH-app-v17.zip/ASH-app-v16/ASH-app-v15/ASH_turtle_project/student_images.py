# Choose a background: "none", "beach", "space", "forest", "city", or "classroom".
# To use your own PNG/GIF, put it in backgrounds/ and write its filename.
background = "forest"

# New simple shape library: triangle(), star(), rectangle(), venetian_blind(), etc.
from turtle_shapes import *
# Keep the rectangle function available even if a drawing list is named rectangle.
shape_rectangle = rectangle
# OPTIONAL EASTER EGG GALLERY — remove # from both marked lines to enable.
# from easter_egg_gallery import easter_egg_sequence

"""STUDENT IMAGES: create pictures independently of sounds."""
from teacher_sequence import Pattern, triangle_shape, square_shape, pentagon_shape, hexagon_shape, star_shape, rectangle_shape

#___make stuff_____________________________________________________________________

colors = ["blue","pink"]

my_line1 = [
 ("up", -3, 0),
 ("heading", 0),
 ("color", "blue"),
 ("width", 4),
 ("down",),
 ("forward", 6),
]

my_line2 = [
 ("up", -3, 1),
 ("heading", 0),
 ("color", "pink"),
 ("width", 40),
 ("down",),
 ("forward", 6),
]

#____play stuff in order top to bottom______________________________________________________________

image_sequence = [
 ("Blue Line", my_line1),
 ("Pink Line", my_line2),
 
]


#__________________________________________________________________





# EASY SHAPE LIBRARY EXAMPLES — uncomment one or more below in image_sequence.
# beach_sun = circle(x=3, y=3, radius=0.7, color="orange", fill="yellow")

# one_triangle = triangle(x=-2, y=-2, size=2, angle=45, color="green")
# blinds = venetian_blind(x=-4, y=-3, width=8, slats=7, slat_height=0.5)
# image_sequence.append(("Venetian blinds", blinds))

# OPTIONAL EASTER EGG GALLERY — uncomment this line AND the import above.
# image_sequence.extend(easter_egg_sequence)


# REPEAT A SHAPE (OPTIONAL)
# Remove the # from the next lines to make five rectangles in a row.
# my_rectangles = repeat_shape(
#     rectangle, count=5, x=-8, y=0, spacing=4,
#     width=3, height=2, color="blue"
# )
# image_sequence.append(("5 Rectangles", my_rectangles))

# REPEAT YOUR OWN DRAWING (OPTIONAL)
# Works with any drawing list that uses ("up", x, y) to position itself.
# my_repeated_lines = repeat_shape(my_blinds, count=3, spacing=3)
# image_sequence.append(("Repeated Drawing", my_repeated_lines))

# ROTATE AND FILL (OPTIONAL EXAMPLES)
# Eight coloured rectangles, each turned another 45 degrees:
# spinning_colours = repeat_shape(
#     shape_rectangle, count=8, x=0, y=0, dx=0, dy=0,
#     rotate=45, width=3, height=1, random_fill=True
# )
# image_sequence.append(("Spinning Colours", spinning_colours))
# One fill colour, repeated upwards:
# rising_stars = repeat_shape(
#     star, count=4, x=0, y=-5, dx=0, dy=3,
#     rotate=20, size=2, fill="yellow"
# )
# image_sequence.append(("Rising Stars", rising_stars))
# For a custom command list, use: repeat_shape(letter_A, count=3, rotate=30)
