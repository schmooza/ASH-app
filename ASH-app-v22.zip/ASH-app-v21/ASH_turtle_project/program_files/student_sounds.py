"""STUDENT MUSIC: choose a chord and a tempo for EACH entry.

Tempo is in beats per minute (BPM). Higher = shorter, faster chord.
60 BPM = 1 second; 120 = 0.5 seconds; 240 = 0.25 seconds.
The music repeats throughout the Turtle drawing.
"""

chord_library = [
    "chord_C", "chord_D", "chord_Em", "chord_F", "chord_G",
    "chord_Am", "chord_Dm", "chord_Bm", "chord_G7", "chord_Cmaj7",
]

# Set a different speed for every chord!
sound_sequence = [
    ("chord_C", 120),
    ("chord_D", 240),
    ("chord_Em", 480),
    ("chord_G", 960),
    ("chord_Am", 180),
    ("chord_F", 360),
    
        ("chord_C", 60),
    ("chord_D", 60),
    ("chord_Em", 80),
    ("chord_G", 80),
    ("chord_Am", 80),
    ("chord_F", 80),
]

# Optional: old-style entries like "chord_C" still use this default tempo.
tempo_bpm = 240
