# Choose a background: "none", "beach", "space", "forest", "city", or "classroom".
# To use your own PNG/GIF, put it in backgrounds/ and write its filename.
background = "forest"

# New simple shape library: triangle(), star(), rectangle(), venetian_blind(), etc.
from turtle_shapes import *

"""STUDENT IMAGES: create pictures independently of sounds."""
from teacher_sequence import Pattern, triangle_shape, square_shape, pentagon_shape, hexagon_shape, star_shape, rectangle_shape

colors = ["red", "pink"]

letter_A = [
    ("speed", 99),  # Medium drawing speed
    ("color", "black"),
    ("width", 25),
    ("up", -4, 0),
    ("heading", 72),
    ("down",),
    ("forward", 3),
    ("heading", 288),
    ("forward", 3),
    ("up", -3, 1),
    ("heading", 0),
    ("down",),
    ("forward", 1),
]


letter_H = [
    ("speed", 6),  # Medium drawing speed
    ("color", "black"),
    ("width", 20),
    ("up", 3, 2),
    ("heading", 270),
    ("down",),
    ("forward", 4),
    ("up", 4, 2),
    ("heading", 270),
    ("down",),
    ("forward", 4),
    ("up", 3, 0),
    ("heading", 0),
    ("down",),
    ("forward", 1),
]

triangles = Pattern("Shrinking triangles")
triangles.at(-2, -3)
triangles.repeat(5)
triangles.shrink()  # Change to .grow() for growing triangles
triangles.random_colors(colors)
triangles.shape([("speed", 99), ("color", "green"), ("width", 3)] + triangle_shape())

letter_S_curved = [
    ("speed", 99),
    ("color", "black"),
    ("width", 35),

    ("up", 0, 2),
    ("heading", 180),
    ("down",),

    ("curve", 2, 180),
    ("curve", 2, -180),
    ("up", -5, 5),
    ("down",),
    ("curve", 2, 90),
    ("curve", 5, -90),
        ("up", 0, 5),
    ("down",),
     ("color", "pink"),
     ("curve", 2, 90),
    ("curve", 5, -90),
    
]


# Built-in rectangle example (4 squares wide, 2 squares high).
# Uncomment the entry in image_sequence below to display it.
rectangle = [
    ("color", "blue"),
    ("fillcolor", "yellow"),
    ("begin_fill",),
] + (
    Pattern("Rectangle")
    .at(-2, -1)
    .shape(rectangle_shape(4, 2))
    .draw()
) + [
    ("end_fill",),
]


# Students choose the order of images here.
one_star = star(x=-2, y=1, size=2, color="purple")

stars = (
    star(x=-4, y=0, size=1, color="purple")
    + star(x=-2, y=0, size=1, color="purple")
    + star(x=0, y=0, size=1, color="purple")
    + star(x=2, y=0, size=1, color="purple")
    + star(x=4, y=0, size=1, color="purple")
)


stars = []

stars += star(x=-2, y=0, size=2, color="red", speed=1)
stars += star(x=2, y=0, size=2, color="blue", speed=100)




image_sequence = [
    ("Star", stars),
    ("S", letter_S_curved),
    ("Letter A", letter_A),
    ("Rectangle", rectangle),
    ("Triangles", triangles),
    
    ("Letter H", letter_H),
]
# EASY SHAPE LIBRARY EXAMPLES — uncomment one or more below in image_sequence.
# beach_sun = circle(x=3, y=3, radius=0.7, color="orange", fill="yellow")

# one_triangle = triangle(x=-2, y=-2, size=2, angle=45, color="green")
# blinds = venetian_blind(x=-4, y=-3, width=8, slats=7, slat_height=0.5)
# image_sequence.append(("Venetian blinds", blinds))
