"""RUN THIS FILE in Thonny (F5).

Student images and student sounds are separate modules. Sounds play one after
another, continuously during the entire drawing, then stop at the end.
"""
from student_images import image_sequence, colors, background
from student_sounds import sound_sequence, tempo_bpm
from teacher_sequence import Sequence, start

show = Sequence()
for title, drawing in image_sequence:
    show.add(title, drawing)

steps = [("start_playlist", sound_sequence, tempo_bpm)] + show.build()
start(steps, colors, background=background)
