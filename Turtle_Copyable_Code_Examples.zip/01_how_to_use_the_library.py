# How to use the library
# Paste into student_images.py.

from turtle_shapes import *


my_triangle = triangle(x=-2, y=-2, size=3,
                         color="blue")
my_star = star(x=1, y=1, size=2,
                color="orange")


image_sequence = [
    ("Triangle", my_triangle),
    ("Star", my_star),
]
