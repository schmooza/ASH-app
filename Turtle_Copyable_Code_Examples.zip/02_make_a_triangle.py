# Make a triangle
# Paste into student_images.py.

my_triangle = triangle(x=-2, y=-2,
                          size=3, angle=45,
                          color="blue", fill="skyblue",
                          speed=5)
