# Make a square
# Paste into student_images.py.

my_square = square(x=-1, y=-1, size=2,
                    angle=20, color="green",
                    fill="lightgreen")
