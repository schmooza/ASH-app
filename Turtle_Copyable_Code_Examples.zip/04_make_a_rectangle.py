# Make a rectangle
# Paste into student_images.py.

my_rectangle = rectangle(x=-3, y=-2,
                            width=5, height=2,
                            angle=0, color="blue",
                            fill="lightblue")
