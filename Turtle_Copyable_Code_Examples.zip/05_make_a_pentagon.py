# Make a pentagon
# Paste into student_images.py.

my_pentagon = pentagon(x=-1, y=-2,
                         size=2, angle=0,
                         color="orange", fill="yellow")
