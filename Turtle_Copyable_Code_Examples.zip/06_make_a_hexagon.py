# Make a hexagon
# Paste into student_images.py.

my_hexagon = hexagon(x=-1, y=-2,
                      size=2, color="purple",
                      fill="lavender")
