# Make a star
# Paste into student_images.py.

my_star = star(x=-2, y=0, size=3,
                angle=0, color="purple",
                fill="yellow", speed=5)
