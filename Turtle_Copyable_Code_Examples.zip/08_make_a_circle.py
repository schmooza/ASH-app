# Make a circle
# Paste into student_images.py.

my_circle = circle(x=0, y=0, radius=1,
                     color="purple", fill="pink",
                     speed=5)
