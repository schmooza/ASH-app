# Make a spiral
# Paste into student_images.py.

my_spiral = spiral(x=0, y=0,
                    turn=90, steps=12,
                    growth=0.2, color="purple",
                    speed=5)
