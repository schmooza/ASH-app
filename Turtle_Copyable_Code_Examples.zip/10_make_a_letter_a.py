# Make a letter A
# Paste into student_images.py.

my_a = letter_a(x=-3, y=-2, size=3,
                  color="red", speed=5)
