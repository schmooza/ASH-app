# Make a letter H
# Paste into student_images.py.

my_h = letter_h(x=-2, y=-2, size=3,
                  color="purple", speed=5)
