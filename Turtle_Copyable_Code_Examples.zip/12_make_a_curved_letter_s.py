# Make a curved letter S
# Paste into student_images.py.

my_s = letter_s(x=0, y=2, radius=1,
                  color="purple", speed=5)
