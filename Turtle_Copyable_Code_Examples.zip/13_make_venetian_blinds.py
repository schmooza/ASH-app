# Make Venetian blinds
# Paste into student_images.py.

my_blinds = venetian_blind(
    x=-4, y=-3, width=8,
    slats=7, slat_height=0.55,
    gap=0.3, color="steelblue",
    fill="lightblue", speed=5
)
