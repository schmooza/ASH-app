# Make a zigzag
# Paste into student_images.py.

my_zigzag = zigzag(x=-4, y=0,
                    steps=6, segment=1,
                    angle=45, color="orange")
