# Repeat a shape
# Paste into student_images.py.

my_row = repeat_shape(
    circle, count=4,
    x=-4, y=0, dx=2, dy=0,
    radius=0.4, color="blue"
)
