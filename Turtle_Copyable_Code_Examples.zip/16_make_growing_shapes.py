# Make growing shapes
# Paste into student_images.py.

my_growth = growing_shapes(
    triangle, count=4,
    x=-3, y=-3,
    start_size=1, step=0.5,
    color="green"
)
