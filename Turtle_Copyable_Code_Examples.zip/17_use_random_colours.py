# Use random colours
# Paste into student_images.py.

my_colours = random_colors(
    star, count=4,
    x=-4, y=0, dx=2,
    size=1,
    palette=["red", "blue", "green", "purple"]
)
