# Choose a background
# Paste into student_images.py.

# Put this near the top of student_images.py
background = "beach"


# Other choices:
# "space", "forest", "city", "classroom", "none"


# Or add a PNG/GIF to backgrounds/:
# background = "my_picture.png"
