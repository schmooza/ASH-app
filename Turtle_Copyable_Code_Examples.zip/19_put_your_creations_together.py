# Put your creations together
# Paste into student_images.py.

background = "space"
from turtle_shapes import *


sun = circle(x=2, y=2, radius=0.7,
              color="orange", fill="yellow")
stars = random_colors(
    star, count=3, x=-4, y=1, dx=1.5,
    size=0.7, palette=["yellow", "white"]
)
planet = circle(x=-1, y=-2, radius=1,
                  color="purple", fill="pink")


image_sequence = [
    ("Sun", sun),
    ("Stars", stars),
    ("Planet", planet),
]
