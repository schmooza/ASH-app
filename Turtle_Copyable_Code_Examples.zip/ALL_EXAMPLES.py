# Grade 6 Turtle — copyable examples
# These examples are separate lessons. Copy the lesson you want into
# student_images.py and add its picture variable to image_sequence.
# Avoid copying multiple image_sequence definitions together.


# ================================================================
# 01_how_to_use_the_library.py
# ================================================================
# How to use the library
# Paste into student_images.py.

from turtle_shapes import *


my_triangle = triangle(x=-2, y=-2, size=3,
                         color="blue")
my_star = star(x=1, y=1, size=2,
                color="orange")


image_sequence = [
    ("Triangle", my_triangle),
    ("Star", my_star),
]


# ================================================================
# 02_make_a_triangle.py
# ================================================================
# Make a triangle
# Paste into student_images.py.

my_triangle = triangle(x=-2, y=-2,
                          size=3, angle=45,
                          color="blue", fill="skyblue",
                          speed=5)


# ================================================================
# 03_make_a_square.py
# ================================================================
# Make a square
# Paste into student_images.py.

my_square = square(x=-1, y=-1, size=2,
                    angle=20, color="green",
                    fill="lightgreen")


# ================================================================
# 04_make_a_rectangle.py
# ================================================================
# Make a rectangle
# Paste into student_images.py.

my_rectangle = rectangle(x=-3, y=-2,
                            width=5, height=2,
                            angle=0, color="blue",
                            fill="lightblue")


# ================================================================
# 05_make_a_pentagon.py
# ================================================================
# Make a pentagon
# Paste into student_images.py.

my_pentagon = pentagon(x=-1, y=-2,
                         size=2, angle=0,
                         color="orange", fill="yellow")


# ================================================================
# 06_make_a_hexagon.py
# ================================================================
# Make a hexagon
# Paste into student_images.py.

my_hexagon = hexagon(x=-1, y=-2,
                      size=2, color="purple",
                      fill="lavender")


# ================================================================
# 07_make_a_star.py
# ================================================================
# Make a star
# Paste into student_images.py.

my_star = star(x=-2, y=0, size=3,
                angle=0, color="purple",
                fill="yellow", speed=5)


# ================================================================
# 08_make_a_circle.py
# ================================================================
# Make a circle
# Paste into student_images.py.

my_circle = circle(x=0, y=0, radius=1,
                     color="purple", fill="pink",
                     speed=5)


# ================================================================
# 09_make_a_spiral.py
# ================================================================
# Make a spiral
# Paste into student_images.py.

my_spiral = spiral(x=0, y=0,
                    turn=90, steps=12,
                    growth=0.2, color="purple",
                    speed=5)


# ================================================================
# 10_make_a_letter_a.py
# ================================================================
# Make a letter A
# Paste into student_images.py.

my_a = letter_a(x=-3, y=-2, size=3,
                  color="red", speed=5)


# ================================================================
# 11_make_a_letter_h.py
# ================================================================
# Make a letter H
# Paste into student_images.py.

my_h = letter_h(x=-2, y=-2, size=3,
                  color="purple", speed=5)


# ================================================================
# 12_make_a_curved_letter_s.py
# ================================================================
# Make a curved letter S
# Paste into student_images.py.

my_s = letter_s(x=0, y=2, radius=1,
                  color="purple", speed=5)


# ================================================================
# 13_make_venetian_blinds.py
# ================================================================
# Make Venetian blinds
# Paste into student_images.py.

my_blinds = venetian_blind(
    x=-4, y=-3, width=8,
    slats=7, slat_height=0.55,
    gap=0.3, color="steelblue",
    fill="lightblue", speed=5
)


# ================================================================
# 14_make_a_zigzag.py
# ================================================================
# Make a zigzag
# Paste into student_images.py.

my_zigzag = zigzag(x=-4, y=0,
                    steps=6, segment=1,
                    angle=45, color="orange")


# ================================================================
# 15_repeat_a_shape.py
# ================================================================
# Repeat a shape
# Paste into student_images.py.

my_row = repeat_shape(
    circle, count=4,
    x=-4, y=0, dx=2, dy=0,
    radius=0.4, color="blue"
)


# ================================================================
# 16_make_growing_shapes.py
# ================================================================
# Make growing shapes
# Paste into student_images.py.

my_growth = growing_shapes(
    triangle, count=4,
    x=-3, y=-3,
    start_size=1, step=0.5,
    color="green"
)


# ================================================================
# 17_use_random_colours.py
# ================================================================
# Use random colours
# Paste into student_images.py.

my_colours = random_colors(
    star, count=4,
    x=-4, y=0, dx=2,
    size=1,
    palette=["red", "blue", "green", "purple"]
)


# ================================================================
# 18_choose_a_background.py
# ================================================================
# Choose a background
# Paste into student_images.py.

# Put this near the top of student_images.py
background = "beach"


# Other choices:
# "space", "forest", "city", "classroom", "none"


# Or add a PNG/GIF to backgrounds/:
# background = "my_picture.png"


# ================================================================
# 19_put_your_creations_together.py
# ================================================================
# Put your creations together
# Paste into student_images.py.

background = "space"
from turtle_shapes import *


sun = circle(x=2, y=2, radius=0.7,
              color="orange", fill="yellow")
stars = random_colors(
    star, count=3, x=-4, y=1, dx=1.5,
    size=0.7, palette=["yellow", "white"]
)
planet = circle(x=-1, y=-2, radius=1,
                  color="purple", fill="pink")


image_sequence = [
    ("Sun", sun),
    ("Stars", stars),
    ("Planet", planet),
]

