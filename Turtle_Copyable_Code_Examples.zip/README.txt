COPYING CODE TO THONNY

1. Open the PDF in a viewer with attachments support (Adobe Acrobat Reader is recommended).
2. Open the attachment ALL_EXAMPLES.py, or use the separate downloadable .py files.
3. Copy the example you want into student_images.py in Thonny.
4. Add the matching variable to image_sequence, then save and run student_sequence.py.

Some browser PDF viewers do not display embedded attachments. Use the companion ZIP in that case.

The PDF also contains selectable code text; copying it may depend on the PDF viewer.
